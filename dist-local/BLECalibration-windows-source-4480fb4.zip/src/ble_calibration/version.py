"""Application version."""

__version__ = "0.9.1"
